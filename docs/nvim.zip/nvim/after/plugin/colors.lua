function ColorMyPencils(color)
	color = color or "rose-pine"
end

ColorMyPencils()
